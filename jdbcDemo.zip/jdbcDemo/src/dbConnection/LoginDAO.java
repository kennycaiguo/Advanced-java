
package dbConnection;
import java.sql.*;

import com.niit.ConnectionProvider;
import com.niit.LoginBean;

public class LoginDAO {
	public static boolean validate(LoginBean bean){  
		boolean status=false;  
		try{  
		Connection con=ConnectionProvider.getCon();  
		              
		PreparedStatement ps=con.prepareStatement(  
		    "select * from login where username=? and password=?");  
		  
		ps.setString(1,bean.getUname());  
		ps.setString(2, bean.getPassword());  
		              
		ResultSet rs=ps.executeQuery();  
		status=rs.next();  
		              
		}catch(Exception e){}  
		  
		return status;  
		  
		}  
	

}
