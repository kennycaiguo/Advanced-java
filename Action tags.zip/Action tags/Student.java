//create java file in java resources  
package com.niit;

import java.io.Serializable;

public class Student implements Serializable{
private String name;

public Student() {
	name="";
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}


}
