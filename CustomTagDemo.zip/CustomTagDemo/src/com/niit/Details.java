package com.niit;

import java.io.IOException;
import javax.servlet.jsp.*;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;

public class Details extends TagSupport {
	 public int doStartTag() {
	      /*This is just to display a message, when
	       * we will use our custom tag. This message
	       * would be displayed
	       */
	      JspWriter out = pageContext.getOut();
	    
			try {
				out.println("This is my own custom tag");
			} catch (IOException e) {
				
				e.printStackTrace();
			}
	
	      return SKIP_BODY;//will not evaluate the body content of the tag  
}
}