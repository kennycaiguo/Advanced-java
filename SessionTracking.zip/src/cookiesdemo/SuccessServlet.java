
package cookiesdemo;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SuccessServlet
 */
public class SuccessServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String u;
		response.setContentType("text/html");  
		
	    PrintWriter out = response.getWriter();  
	      Cookie[] cookies=request.getCookies();
	   for(Cookie c:cookies) 
	   {
		if(c.getName().equals("user"))   
		{
	     u=c.getValue();
	      out.print("Hello  In cookies "+u); 
		}
		
	}
	   
	   for(Cookie c:cookies) 
	   { out.println("<br>");
		   out.println(c+" values"+ c.getValue());
	   }
}
}