package com.niit;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;





public class JpaTest {

	public static void main(String[] args) {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPAORMDemo");
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();
		
		transaction.begin();
		Student s=new Student();
		s.setId(89);
		s.setName("Johooo");
		em.persist(s);//insert into customer values(260,'janani');
		transaction.commit();
		
		  // Remove entity 
	    
			em.getTransaction().begin();
			em.remove(s);
			em.getTransaction().commit();
			// Retrieve entity 
		  Query q = em.createQuery("SELECT s FROM Student s");
        List<Student> custList = q.getResultList();
        Iterator studIterator=custList.iterator();
       while(studIterator.hasNext()) {
      	 System.out.println(studIterator.next());
       }
       
     

	}

}
